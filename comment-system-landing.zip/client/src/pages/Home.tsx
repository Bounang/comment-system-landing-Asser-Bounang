import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Download, Code2, Zap, Shield, GitBranch, Terminal } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-950/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Code2 className="w-8 h-8 text-blue-600" />
            <span className="font-bold text-xl text-slate-900 dark:text-white">CommentSystem</span>
          </div>
          <a href="#download" className="text-blue-600 hover:text-blue-700 font-medium">
            Télécharger
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <div className="inline-block mb-4">
            <Badge variant="outline" className="px-4 py-2 text-sm">
              🚀 Projet Complet et Prêt à Utiliser
            </Badge>
          </div>
          <h1 className="text-5xl sm:text-6xl font-bold text-slate-900 dark:text-white mb-6">
            Système de Commentaires Moderne
          </h1>
          <p className="text-xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto mb-8">
            Une application web complète avec front-end Vue.js, back-end Node.js/Express, authentification JWT et une architecture modulaire respectant les principes du génie logiciel.
          </p>
          <div className="flex gap-4 justify-center">
            <a href="#download">
              <Button size="lg" className="gap-2">
                <Download className="w-5 h-5" />
                Télécharger le Projet
              </Button>
            </a>
            <a href="#structure">
              <Button size="lg" variant="outline">
                Voir la Structure
              </Button>
            </a>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-20">
          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <Zap className="w-8 h-8 text-amber-500 mb-2" />
              <CardTitle>Performant</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-600 dark:text-slate-400">
              Vue.js avec Pinia pour une réactivité optimale et une gestion d'état centralisée.
            </CardContent>
          </Card>

          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <Shield className="w-8 h-8 text-green-500 mb-2" />
              <CardTitle>Sécurisé</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-600 dark:text-slate-400">
              Authentification JWT, hachage des mots de passe avec bcrypt, autorisation basée sur les rôles.
            </CardContent>
          </Card>

          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <GitBranch className="w-8 h-8 text-purple-500 mb-2" />
              <CardTitle>Modulaire</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-600 dark:text-slate-400">
              Architecture propre avec séparation des préoccupations et composants réutilisables.
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Structure Section */}
      <section id="structure" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 border-t border-slate-200 dark:border-slate-800">
        <h2 className="text-4xl font-bold text-slate-900 dark:text-white mb-12">Structure du Projet</h2>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Frontend */}
          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code2 className="w-5 h-5 text-blue-600" />
                Frontend (Vue.js)
              </CardTitle>
              <CardDescription>Application web interactive avec Pinia et Tailwind CSS</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-slate-50 dark:bg-slate-900 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                <pre className="text-slate-700 dark:text-slate-300">{`frontend/
├── src/
│   ├── components/
│   │   ├── Comment.vue
│   │   └── CommentForm.vue
│   ├── stores/
│   │   ├── auth.js
│   │   └── comments.js
│   ├── views/
│   │   ├── HomeView.vue
│   │   └── LoginView.vue
│   ├── assets/
│   │   └── main.css
│   ├── App.vue
│   └── main.js
├── index.html
└── package.json`}</pre>
              </div>
            </CardContent>
          </Card>

          {/* Backend */}
          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Terminal className="w-5 h-5 text-green-600" />
                Backend (Node.js/Express)
              </CardTitle>
              <CardDescription>API REST sécurisée avec authentification JWT</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-slate-50 dark:bg-slate-900 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                <pre className="text-slate-700 dark:text-slate-300">{`backend/
├── config.js
├── db.json
├── server.js
└── package.json

Routes API:
├── POST   /api/register
├── POST   /api/login
├── GET    /api/comments
├── POST   /api/comments
└── DELETE /api/comments/:id`}</pre>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Key Features */}
        <Card className="border-slate-200 dark:border-slate-800">
          <CardHeader>
            <CardTitle>Fonctionnalités Implémentées</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-slate-900 dark:text-white mb-3">Système de Commentaires</h4>
                <ul className="space-y-2 text-slate-600 dark:text-slate-400">
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600 mt-1">✓</span>
                    <span>Affichage et création de commentaires</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600 mt-1">✓</span>
                    <span>Système de réponses imbriquées</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600 mt-1">✓</span>
                    <span>Réactions multiples avec emojis</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600 mt-1">✓</span>
                    <span>Système de repartage (citation)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-600 mt-1">✓</span>
                    <span>Recherche en temps réel</span>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-slate-900 dark:text-white mb-3">Gestion et Sécurité</h4>
                <ul className="space-y-2 text-slate-600 dark:text-slate-400">
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-1">✓</span>
                    <span>Authentification JWT</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-1">✓</span>
                    <span>Hachage sécurisé des mots de passe</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-1">✓</span>
                    <span>Système de rôles (user, moderator, admin)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-1">✓</span>
                    <span>Menu d'actions (modifier, supprimer, signaler)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-600 mt-1">✓</span>
                    <span>Affichage conditionnel basé sur les droits</span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Getting Started Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 border-t border-slate-200 dark:border-slate-800">
        <h2 className="text-4xl font-bold text-slate-900 dark:text-white mb-12">Démarrage Rapide</h2>

        <div className="space-y-6">
          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <CardTitle className="text-lg">1. Prérequis</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 dark:text-slate-400 mb-4">
                Assurez-vous d'avoir Node.js et npm installés sur votre machine.
              </p>
              <div className="bg-slate-900 dark:bg-slate-950 p-4 rounded-lg">
                <code className="text-slate-100 text-sm">node -v && npm -v</code>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <CardTitle className="text-lg">2. Extraire et Naviguer</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 dark:text-slate-400 mb-4">
                Dézippez le fichier téléchargé et naviguez dans le répertoire du projet.
              </p>
              <div className="bg-slate-900 dark:bg-slate-950 p-4 rounded-lg">
                <code className="text-slate-100 text-sm">unzip manus-comment-system.zip<br/>cd manus-comment-system</code>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <CardTitle className="text-lg">3. Lancer le Backend</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 dark:text-slate-400 mb-4">
                Ouvrez un terminal et lancez le serveur API.
              </p>
              <div className="bg-slate-900 dark:bg-slate-950 p-4 rounded-lg space-y-2">
                <div>
                  <code className="text-slate-100 text-sm">cd backend</code>
                </div>
                <div>
                  <code className="text-slate-100 text-sm">npm install</code>
                </div>
                <div>
                  <code className="text-slate-100 text-sm">npm run dev</code>
                </div>
              </div>
              <p className="text-slate-500 dark:text-slate-400 text-sm mt-3">
                Le serveur démarrera sur http://localhost:3000
              </p>
            </CardContent>
          </Card>

          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <CardTitle className="text-lg">4. Lancer le Frontend</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 dark:text-slate-400 mb-4">
                Ouvrez un autre terminal et lancez l'application Vue.
              </p>
              <div className="bg-slate-900 dark:bg-slate-950 p-4 rounded-lg space-y-2">
                <div>
                  <code className="text-slate-100 text-sm">cd frontend</code>
                </div>
                <div>
                  <code className="text-slate-100 text-sm">npm install</code>
                </div>
                <div>
                  <code className="text-slate-100 text-sm">npm run dev</code>
                </div>
              </div>
              <p className="text-slate-500 dark:text-slate-400 text-sm mt-3">
                L'application s'ouvrira sur http://localhost:5173
              </p>
            </CardContent>
          </Card>

          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <CardTitle className="text-lg">5. Accéder à l'Application</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 dark:text-slate-400 mb-4">
                Ouvrez votre navigateur et accédez à l'application. Vous pouvez vous inscrire et commencer à utiliser le système de commentaires.
              </p>
              <div className="bg-slate-900 dark:bg-slate-950 p-4 rounded-lg">
                <code className="text-slate-100 text-sm">http://localhost:5173</code>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Download Section */}
      <section id="download" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 border-t border-slate-200 dark:border-slate-800">
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-center text-white">
          <h2 className="text-4xl font-bold mb-6">Prêt à Commencer ?</h2>
          <p className="text-xl mb-8 opacity-90">
            Téléchargez le projet complet et commencez à développer votre système de commentaires.
          </p>
          <Button size="lg" variant="secondary" className="gap-2 text-lg">
            <Download className="w-6 h-6" />
            Télécharger manus-comment-system.zip
          </Button>
          <p className="text-sm opacity-75 mt-6">
            Projet complet avec front-end Vue.js, back-end Node.js/Express et authentification JWT
          </p>
        </div>
      </section>

      {/* Tech Stack Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 border-t border-slate-200 dark:border-slate-800">
        <h2 className="text-4xl font-bold text-slate-900 dark:text-white mb-12">Stack Technologique</h2>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <CardTitle>Frontend</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">Vue.js 3</span>
                <Badge>Framework</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">Pinia</span>
                <Badge>State Management</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">Vue Router</span>
                <Badge>Routing</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">Tailwind CSS</span>
                <Badge>Styling</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">Vite</span>
                <Badge>Build Tool</Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <CardTitle>Backend</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">Node.js</span>
                <Badge>Runtime</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">Express</span>
                <Badge>Framework</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">JWT</span>
                <Badge>Authentication</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">bcryptjs</span>
                <Badge>Security</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-600 dark:text-slate-400">CORS</span>
                <Badge>Middleware</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Next Steps Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 border-t border-slate-200 dark:border-slate-800">
        <h2 className="text-4xl font-bold text-slate-900 dark:text-white mb-12">Prochaines Étapes</h2>

        <div className="grid md:grid-cols-3 gap-6">
          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <CardTitle className="text-lg">1. Exploration</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-600 dark:text-slate-400">
              Explorez la structure du projet, comprenez comment les composants Vue communiquent avec le backend Express.
            </CardContent>
          </Card>

          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <CardTitle className="text-lg">2. Personnalisation</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-600 dark:text-slate-400">
              Adaptez les styles, les couleurs et les fonctionnalités selon vos besoins spécifiques.
            </CardContent>
          </Card>

          <Card className="border-slate-200 dark:border-slate-800">
            <CardHeader>
              <CardTitle className="text-lg">3. Extension</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-600 dark:text-slate-400">
              Ajoutez de nouvelles fonctionnalités comme l'upload de fichiers, les notifications ou une vraie base de données.
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <Code2 className="w-6 h-6 text-blue-600" />
              <span className="font-bold text-slate-900 dark:text-white">CommentSystem</span>
            </div>
            <p className="text-slate-600 dark:text-slate-400 text-sm">
              Un projet complet respectant les principes du génie logiciel moderne.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
